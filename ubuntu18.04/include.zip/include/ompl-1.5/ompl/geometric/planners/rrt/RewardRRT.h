/*********************************************************************
* Software License Agreement (BSD License)
*
*  Copyright (c) 2015, Rice University
*  All rights reserved.
*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*   * Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*   * Redistributions in binary form must reproduce the above
*     copyright notice, this list of conditions and the following
*     disclaimer in the documentation and/or other materials provided
*     with the distribution.
*   * Neither the name of the Rice University nor the names of its
*     contributors may be used to endorse or promote products derived
*     from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
*  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
*  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
*  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
*  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
*  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
*  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
*  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
*  POSSIBILITY OF SUCH DAMAGE.
*********************************************************************/

/* Author: Ryan Luna */

#ifndef OMPL_GEOMETRIC_PLANNERS_RRT_REWARDRRT_
#define OMPL_GEOMETRIC_PLANNERS_RRT_REWARDRRT_

#include <cmath>
#include "ompl/geometric/planners/PlannerIncludes.h"
#include "ompl/datastructures/NearestNeighbors.h"
#include "ompl/base/OptimizationObjective.h"
#include <Eigen/Dense>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include<fstream>

namespace ompl
{
    namespace geometric
    {
        class RewardRRT : public base::Planner
        {
        public:

            //概率权重
            double weight_reward_cum;
            double weight_reward_inc;
            double bias_start;
            double bias_goal;
            //start KF
            double start_sigma_R_cum_0;
            double start_sigma_Delta_R_0;
            double start_q_R_cum;
            double start_q_Delta_R;
            Eigen::Vector2d start_x; //状态空间
            Eigen::Matrix2d start_P; //协方差
            Eigen::Vector2d start_x_pred;//预测状态
            Eigen::Matrix2d start_P_pred;//预测协方差
            double start_z;//测量值
            Eigen::Vector2d start_K;//卡尔曼增益
            Eigen::Matrix2d start_F;//状态转移方程
            Eigen::Vector2d start_H;//测量矩阵
            Eigen::Matrix2d start_Q;//过程噪声

            //goal KF
            double goal_sigma_R_cum_0;//累计奖励的方差
            double goal_sigma_Delta_R_0;//单步奖励的方差
            double goal_q_R_cum;//累计奖励的过程噪声
            double goal_q_Delta_R;//单步奖励的过程噪声
            Eigen::Vector2d goal_x; //状态空间
            Eigen::Matrix2d goal_P; //协方差
            Eigen::Vector2d goal_x_pred;//预测状态
            Eigen::Matrix2d goal_P_pred;//预测协方差
            double goal_z;//测量值
            Eigen::Vector2d goal_K;//卡尔曼增益
            Eigen::Matrix2d goal_F;//状态转移方程
            Eigen::Vector2d goal_H;//测量矩阵
            Eigen::Matrix2d goal_Q;//过程噪声

            double R=0.1;
            
            double positive_sigma_limit;//限制无碰奖励值过高的调整因子
            double negtive_sigma_limit;//限制有碰奖励值过高的调整因子
            double positive_reward_limit;//起始点到目标点的无碰奖励值极限
            double negtive_reward_limit;//起始点到目标点的有碰奖励值极限
            double start_reward_cum;
            double start_reward_inc;
            double goal_reward_cum;
            double goal_reward_inc;
            double goalBias_;

            unsigned int getDOF();
            void StartJointStatePrint(double *jointstate,double pheromone);
            void GoalJointStatePrint(double *jointstate,double pheromone);
            void PVF(std::vector<double>& pheromone);
            int FindMaxPheromone(const std::vector<double>& vec);
            void CompositionState(base::State *com_state, base::State *state1, base::State *state2);
            double BiasCalculate(Eigen::Vector2d state);
            void StartStatePrint(std::string info_type);
            void GoalStatePrint(std::string info_type);
            void KFInit();
            void StartStateUpdate(double reward_inc);
            void GoalStateUpdate(double reward_inc);
            void DoublePrint(double param,std::string filename);
            void FileClear(std::string filename);
            /// Constructor
            RewardRRT(const base::SpaceInformationPtr &si);
            ~RewardRRT() override;
            void clear() override;
            void setup() override;
            void getPlannerData(base::PlannerData &data) const override;
            base::PlannerStatus solve(const base::PlannerTerminationCondition &ptc) override;

            /// \brief Set the maximum possible length of any one motion in
            ///  the search tree.  Very short/long motions may inhibit
            ///  the exploratory capabilities of the planner.
            void setRange(double distance)
            {
                maxDistance_ = distance;
            }

            /// \brief Get the range the planner is using
            double getRange() const
            {
                return maxDistance_;
            }

            /// \brief Set the factor by which the temperature is increased
            /// after a failed transition test.  This value should be in the
            /// range (0, 1], typically close to zero (default is 0.1).
            /// This value is an exponential (e^factor) that is multiplied with
            /// the current temperature.
            void setTempChangeFactor(double factor)
            {
                tempChangeFactor_ = exp(factor);
            }

            /// \brief Get the factor by which the temperature is
            /// increased after a failed transition.
            double getTempChangeFactor() const
            {
                return log(tempChangeFactor_);
            }

            /// \brief Set the cost threshold (default is infinity).
            /// Any motion cost that is not better than this cost (according to
            /// the optimization objective) will not be expanded by the planner.
            void setCostThreshold(double maxCost)
            {
                costThreshold_ = base::Cost(maxCost);
            }

            /// \brief Get the cost threshold (default is infinity).
            /// Any motion cost that is not better than this cost (according to
            /// the optimization objective) will not be expanded by the planner. */
            double getCostThreshold() const
            {
                return costThreshold_.value();
            }

            /// \brief Set the initial temperature at the start of planning.
            /// Should be high to allow for initial exploration.
            void setInitTemperature(double initTemperature)
            {
                initTemperature_ = initTemperature;
            }

            /// \brief Get the initial temperature at the start of planning.
            double getInitTemperature() const
            {
                return initTemperature_;
            }

            /// \brief Set the distance between a new state and the nearest
            /// neighbor that qualifies a state as being a frontier node.
            void setFrontierThreshold(double frontierThreshold)
            {
                frontierThreshold_ = frontierThreshold;
            }

            /// \brief Get the distance between a new state and the nearest
            /// neighbor that qualifies a state as being a frontier node.
            double getFrontierThreshold() const
            {
                return frontierThreshold_;
            }

            /// \brief Set the ratio between adding non-frontier nodes to
            /// frontier nodes.  For example: .1 is one non-frontier node for
            /// every 10 frontier nodes added.
            void setFrontierNodeRatio(double frontierNodeRatio)
            {
                frontierNodeRatio_ = frontierNodeRatio;
            }

            /// \brief Get the ratio between adding non-frontier nodes to
            /// frontier nodes.
            double getFrontierNodeRatio() const
            {
                return frontierNodeRatio_;
            }

            /// \brief Set a different nearest neighbors datastructure
            template <template <typename T> class NN>
            void setNearestNeighbors()
            {
                if ((tStart_ && tStart_->size() != 0) || (tGoal_ && tGoal_->size() != 0))
                    OMPL_WARN("Calling setNearestNeighbors will clear all states.");
                clear();
                tStart_ = std::make_shared<NN<Motion *>>();
                tGoal_ = std::make_shared<NN<Motion *>>();
                setup();
            }

        protected:
            /// \brief Representation of a motion in the search tree
            class Motion
            {
            public:
                /// \brief Default constructor
                Motion() = default;

                /// \brief Constructor that allocates memory for the state
                Motion(const base::SpaceInformationPtr &si) : state(si->allocState())
                {
                }

                ~Motion() = default;

                /// \brief The state contained by the motion
                base::State *state{nullptr};

                /// \brief The parent motion in the exploration tree
                Motion *parent{nullptr};

                /// \brief Cost of the state
                base::Cost cost;

                /// \brief Pointer to the root of the tree this motion is
                /// contained in.
                const base::State *root{nullptr};
            };

            /// \brief Free all memory allocated during planning
            void freeMemory();

            /// \brief The nearest-neighbors data structure that contains the
            /// entire the tree of motions generated during planning.
            using TreeData = std::shared_ptr<NearestNeighbors<Motion *>>;

            /// \brief Add a state to the given tree.  The motion created
            /// is returned.
            Motion *addMotion(const base::State *state, TreeData &tree, Motion *parent = nullptr);

            /// \brief The result of a call to extendTree
            enum GrowResult
            {
                /// No extension was possible
                FAILED,
                /// Progress was made toward extension
                ADVANCED,
                /// The desired state was reached during extension
                SUCCESS
            };

            /// \brief Extend \e tree toward the state in \e rmotion.
            /// Store the result of the extension, if any, in result
            GrowResult extendTree(Motion *toMotion, TreeData &tree, Motion *&result);

            /// \brief Extend \e tree from \e nearest toward \e toMotion.
            /// Store the result of the extension, if any, in result
            GrowResult extendTree(Motion *nearest, TreeData &tree, Motion *toMotion, Motion *&result);

            /// \brief Attempt to connect \e tree to \e nmotion, which is in
            /// the other tree.  \e xmotion is scratch space and will be overwritten
            bool connectTrees(Motion *nmotion, TreeData &tree, Motion *xmotion);

            GrowResult extendTree(Motion *toMotion, TreeData &tree, Motion *&result, 
                                  std::vector<Motion *>& startmotiontree, std::vector<Motion *>& goalmotiontree,
                                  std::vector<double>& start_pheromone,std::vector<double>& goal_pheromone);

            /// \brief Extend \e tree from \e nearest toward \e toMotion.
            /// Store the result of the extension, if any, in result
            GrowResult extendTree(Motion *nearest, TreeData &tree, Motion *toMotion, Motion *&result
                                , std::vector<Motion *>& startmotiontree, std::vector<Motion *>& goalmotiontree,
                                std::vector<double>& start_pheromone,std::vector<double>& goal_pheromone);

            /// \brief Attempt to connect \e tree to \e nmotion, which is in
            /// the other tree.  \e xmotion is scratch space and will be overwritten
            bool connectTrees(Motion *nmotion, TreeData &tree, Motion *xmotion, 
                              std::vector<Motion *>& startmotiontree, std::vector<Motion *>& goalmotiontree,
                              std::vector<double>& start_pheromone,std::vector<double>& goal_pheromone);


            /// \brief Compute distance between motions (actually distance between contained states)
            double distanceFunction(const Motion *a, const Motion *b) const
            {
                return si_->distance(a->state, b->state);
            }

            /// \brief The maximum length of a motion to be added to a tree
            double maxDistance_{0.};

            /// \brief The factor by which the temperature is increased after
            /// a failed transition test.
            double tempChangeFactor_;

            /// \brief The most desirable (e.g., minimum) cost value in the search tree
            base::Cost bestCost_;

            /// \brief The least desirable (e.g., maximum) cost value in the search tree
            base::Cost worstCost_;

            /// \brief All motion costs must be better than this cost (default is infinity)
            base::Cost costThreshold_{std::numeric_limits<double>::infinity()};

            /// \brief The temperature that planning begins at.
            double initTemperature_{100.};

            /// \brief The distance between an existing state and a new state
            /// that qualifies it as a frontier state.
            double frontierThreshold_{0.};

            /// \brief The target ratio of non-frontier nodes to frontier nodes.
            double frontierNodeRatio_{.1};

            /// \brief The current temperature
            double temp_;

            /// \brief A count of the number of non-frontier nodes in the trees
            double nonfrontierCount_;

            /// \brief A count of the number of frontier nodes in the trees
            double frontierCount_;

            /// \brief The range at which the algorithm will attempt to connect
            /// the two trees.
            double connectionRange_;

            /// \brief The most recent connection point for the two trees.
            /// Used for PlannerData computation.
            std::pair<Motion *, Motion *> connectionPoint_{nullptr, nullptr};

            /// \brief The start tree
            TreeData tStart_;

            /// \brief The goal tree
            TreeData tGoal_;

            /// \brief The objective (cost function) being optimized
            ompl::base::OptimizationObjectivePtr opt_;
        };

    }
}

#endif